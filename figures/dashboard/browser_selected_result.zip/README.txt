Simulated thermal exposure only. Fish spoilage is NOT_CALIBRATED.
Temperatures are Celsius; exposure is degree-hours above a selected comparison reference.
Scenario timestamps are arbitrary UTC epochs, not actual shipment times.
